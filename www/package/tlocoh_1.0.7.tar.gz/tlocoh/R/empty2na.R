empty2na <- function(x) return(ifelse(length(x)==0,NA,x))
