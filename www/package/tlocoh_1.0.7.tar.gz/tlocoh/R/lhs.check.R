

lhs.check <- function(lhs, lxy, ptid="auto", hs.idx=1) {

# This function checks a single hull in lhs to make sure it was constructed correctly.
# It presumes that the hullset was constructed from lxy, and will manually reidentify 
# the nearest neighbors and hull metrics (or just plot)

  # plot hull and neighbors
  # make sure anv is correct
  # check hull area / perimeter
  # find enc.pts using point.in.polygon
  
  ## if spatial overlap metrics are present, recreate those
                                                            

}

