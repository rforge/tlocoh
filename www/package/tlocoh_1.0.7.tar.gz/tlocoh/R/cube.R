#' Cubes a number
#' @param x a number
#' @return x^3
#' @export
cube <- function(x) {
    x^3
}
