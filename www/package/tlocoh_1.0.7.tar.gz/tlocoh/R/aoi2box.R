#' Converts a dataframe with upper-left / lower-right coordinates of a box to a closed polygon
#'
#' @param aoi A two-column xy data frame containing the upper left point and the lower right point in the first and second rows respectively
#'
#' @return Two column dataframe containing the xy coordinates of a closed rectangle that can be plotted using points() or polygons()
#'
#' @note
#' You can use the \code{aoi} function to select two coordinates on the active plot window with the mouse, then draw that rectangle on other
#' plots with \code{aoi2box}.
#'
#' @seealso \code{\link{aoi}}
#'
#' @examples
#' myaoi <- aoi()
#' polygons(myaoi)
#'
#' @export

aoi2box <- function(aoi) {
    ## Takes a two-column xy data frame containing the upper left point of an aoi in row 1 and the lower right point in row 2, 
    ## and returns a xy data frame with five points of a closed rectangle that can be plotted using points() or polygons()
    return(data.frame(x=c(aoi[1,1], aoi[2,1], aoi[2,1], aoi[1,1], aoi[1,1]), y=c(aoi[1,2], aoi[1,2], aoi[2,2], aoi[2,2], aoi[1,2])))
}

