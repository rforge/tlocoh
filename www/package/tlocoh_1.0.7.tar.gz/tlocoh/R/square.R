#' square
#' @export
square <-
function(x) {
    x^2
}
